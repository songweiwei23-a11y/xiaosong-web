$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
cd "C:\Users\30430\Desktop\�ർ֪ʶ��ȫ\С��\xiaosong-web"
& "C:\Program Files\nodejs\npm.cmd" run dev
