// 19种脚本结构的详细定义和质量标准
//
// 本文件原先没有任何 export，343 行内容无法被引用，等同死代码。
// 它与 script-details 的结构条目一一对应，但多出 coreLogic 与
// emotionCurve 两个字段——前者说明该结构适用的用户处境，后者给出
// 情绪推进路径，正是提示词里反复强调的"情绪波点"的上位设计。
// 这里补上 export，并提供只取增量字段的函数，避免与 script-details
// 形成两套互相覆盖的结构数据。
export const SCRIPT_STRUCTURE_DETAILS = {
  problem: {
    name: "解题型",
    formula: "难题呈现 → 危机升级 → 解决方案 → 执行步骤",
    coreLogic: "用户有具体问题需要解决",
    emotionCurve: "焦虑 → 共鸣 → 希望 → 行动力",
    keyPoints: [
      "开场必须展示用户真实遇到的具体难题",
      "中段用'如果不解决会怎样'放大焦虑",
      "给出的解决方案要可落地、分步骤",
      "结尾要有明确的行动指令"
    ],
    avoidMistakes: [
      "不要泛泛而谈问题，要具体到场景",
      "不要只说问题不给方案",
      "方案不要太复杂，3步以内最佳"
    ]
  },
  recommend: {
    name: "推荐型",
    formula: "美好愿景 → 目标人群 → 制造好奇 → 推荐理由",
    coreLogic: "给用户一个值得尝试的选项",
    emotionCurve: "向往 → 认同 → 好奇 → 行动",
    keyPoints: [
      "开场描绘使用后的美好结果",
      "明确'适合谁、不适合谁'",
      "推荐理由要有数据或案例支撑",
      "结尾降低尝试门槛"
    ],
    avoidMistakes: [
      "不要像广告一样硬推",
      "不要只说好不说适用人群",
      "理由不要虚，要有具体证据"
    ]
  },
  expose: {
    name: "揭秘型",
    formula: "反常识观点 → 内幕揭露 → 真相示范",
    coreLogic: "打破用户认知，建立权威",
    emotionCurve: "疑惑 → 震惊 → 恍然大悟",
    keyPoints: [
      "开场抛出反常识观点制造冲突",
      "用内幕信息建立专业可信度",
      "必须有具体案例或证据支撑",
      "避免过度夸张失去可信度"
    ],
    avoidMistakes: [
      "不要为了反常识而反常识",
      "内幕信息要真实可查证",
      "不要揭秘完就结束，要给结论"
    ]
  },
  case: {
    name: "案例型",
    formula: "案例呈现 → 关键拆解 → 可复制方法",
    coreLogic: "用真实案例降低用户行动门槛",
    emotionCurve: "好奇 → 学习 → 跃跃欲试",
    keyPoints: [
      "案例要真实具体，有数据有细节",
      "拆解要聚焦1-2个核心点",
      "给出的方法要普通人能复制",
      "结尾要降低'我也能做'的心理门槛"
    ],
    avoidMistakes: [
      "不要选太特殊的案例（明星、大V）",
      "拆解不要太多点，抓核心",
      "方法不要需要特殊资源"
    ]
  },
  train: {
    name: "火车节型",
    formula: "目标宣布 → 过程记录 → 结果展示",
    coreLogic: "用过程感带来真实可信",
    emotionCurve: "好奇 → 陪伴感 → 满足",
    keyPoints: [
      "开场明确今天要做什么",
      "中段记录关键节点和细节",
      "结果要有视觉冲击或意外感",
      "全程用第一视角增强代入感"
    ],
    avoidMistakes: [
      "不要剪辑得太碎失去连贯性",
      "过程不要太平淡没有波澜",
      "结果要超出预期才有记忆点"
    ]
  },
  argue: {
    name: "论证型",
    formula: "观点抛出 → 论据支撑 → 主题升华",
    coreLogic: "输出价值观，筛选精准用户",
    emotionCurve: "认同 → 共鸣 → 追随",
    keyPoints: [
      "观点要鲜明、有立场、有争议",
      "论据要多角度（数据、案例、对比）",
      "升华要有金句，可转发",
      "适合建立IP人设"
    ],
    avoidMistakes: [
      "观点不要模棱两可",
      "论据不要单一，至少3个角度",
      "不要说教，要像聊天"
    ]
  },
  story: {
    name: "故事型",
    formula: "现状铺垫 → 困境冲突 → 转折高潮 → 成就结局",
    coreLogic: "用故事情节吸引完播",
    emotionCurve: "代入 → 焦虑 → 惊喜 → 满足",
    keyPoints: [
      "开场要有代入感（时间、地点、人物）",
      "困境要具体，让人感同身受",
      "转折要意外但合理",
      "结局要有启发或金句"
    ],
    avoidMistakes: [
      "不要拖沓，60秒只讲一个故事",
      "转折不要太突兀失去真实感",
      "结局不要强行鸡汤"
    ]
  },
  compare: {
    name: "对比型",
    formula: "A方案 vs B方案对比 → 差异揭示 → 推荐结论",
    coreLogic: "用对比制造视觉冲击和认知差",
    emotionCurve: "好奇 → 震惊 → 决策",
    keyPoints: [
      "对比要极端化（价格、时间、效果）",
      "用数字和画面增强对比",
      "揭示背后原因而非停留在表面",
      "给出明确的选择建议"
    ],
    avoidMistakes: [
      "不要为了对比而夸大",
      "不要只对比不解释原因",
      "结论不要模糊，要有倾向"
    ]
  },
  list: {
    name: "清单型",
    formula: "主题承诺 → 逐条展开 → 总结强化",
    coreLogic: "用结构化信息降低理解成本",
    emotionCurve: "期待 → 收获感 → 满足",
    keyPoints: [
      "开场承诺X个方法/技巧/理由",
      "每条要简短、可记忆、可执行",
      "用数字或emoji增强记忆点",
      "最后一条要最有冲击力"
    ],
    avoidMistakes: [
      "条数不要超过5个（记不住）",
      "每条长度要均衡",
      "不要变成简单罗列"
    ]
  },
  timeline: {
    name: "时间线型",
    formula: "过去状态 → 中间变化 → 现在结果",
    coreLogic: "用时间对比制造反差",
    emotionCurve: "共鸣 → 惊讶 → 启发",
    keyPoints: [
      "过去和现在要有强烈反差",
      "中间转折点要具体说明",
      "用对比画面增强视觉冲击",
      "提炼出可学习的方法"
    ],
    avoidMistakes: [
      "时间跨度不要太长（难以验证）",
      "变化不要归功于玄学",
      "要说清楚具体做了什么"
    ]
  },
  qa: {
    name: "问答型",
    formula: "提出问题 → 分析原因 → 给出答案",
    coreLogic: "解决用户真实疑问",
    emotionCurve: "共鸣 → 好奇 → 豁然开朗",
    keyPoints: [
      "问题要是用户真实想知道的",
      "分析要打破常见误区",
      "答案要简单直接可执行",
      "可以用反问增强互动"
    ],
    avoidMistakes: [
      "不要自问自答太生硬",
      "答案不要太复杂",
      "不要回避问题绕圈子"
    ]
  },
  scene: {
    name: "情景剧型",
    formula: "场景设定 → 冲突发生 → 反转收尾",
    coreLogic: "用剧情吸引完播率",
    emotionCurve: "代入 → 紧张 → 意外 → 满足",
    keyPoints: [
      "场景要日常（办公室、家里、街头）",
      "冲突要戏剧化但不过分",
      "反转要在最后5秒",
      "台词要口语化、有梗"
    ],
    avoidMistakes: [
      "不要尴尬演戏",
      "剧情不要太复杂",
      "反转不要为了反转而反转"
    ]
  },
  review: {
    name: "测评型",
    formula: "产品介绍 → 多维度测试 → 结论建议",
    coreLogic: "用客观测试建立信任",
    emotionCurve: "好奇 → 期待 → 认同",
    keyPoints: [
      "测试维度要全面（3-5个）",
      "过程要有对比（好的vs差的）",
      "结论要明确（推荐/不推荐）",
      "测试要可视化（有画面）"
    ],
    avoidMistakes: [
      "不要只夸不批评",
      "测试不要太主观",
      "不要忽略缺点"
    ]
  },
  challenge: {
    name: "挑战型",
    formula: "挑战宣布 → 过程展示 → 结果揭晓",
    coreLogic: "用挑战制造悬念",
    emotionCurve: "好奇 → 紧张 → 惊喜/失望",
    keyPoints: [
      "挑战要有难度但可完成",
      "过程要有波折和细节",
      "结果要有意外感",
      "失败也要有价值输出"
    ],
    avoidMistakes: [
      "不要选不可能完成的挑战",
      "过程不要注水",
      "失败不要没有复盘"
    ]
  },
  tutorial: {
    name: "教程型",
    formula: "目标明确 → 步骤1→2→3 → 结果展示",
    coreLogic: "手把手教会用户",
    emotionCurve: "学习欲 → 理解 → 想尝试",
    keyPoints: [
      "步骤要清晰（不超过5步）",
      "每步要有画面展示",
      "难点要特写或慢放",
      "结果要有视觉吸引力"
    ],
    avoidMistakes: [
      "不要跳步骤",
      "不要只说不做",
      "不要太快看不清"
    ]
  },
  reverse: {
    name: "反转型",
    formula: "预期A → 过程铺垫 → 实际B（反转）",
    coreLogic: "用反差制造记忆点",
    emotionCurve: "预判 → 紧张 → 意外",
    keyPoints: [
      "前30秒铺垫要自然",
      "反转要在最后10秒",
      "反转要意外但合理",
      "反转后要有金句"
    ],
    avoidMistakes: [
      "不要铺垫太久",
      "反转不要太突兀",
      "不要为了反转而反转"
    ]
  },
  summary: {
    name: "盘点型",
    formula: "主题引入 → 逐项盘点 → 总结升华",
    coreLogic: "用盘点满足收集欲",
    emotionCurve: "好奇 → 收获 → 满足",
    keyPoints: [
      "盘点要有逻辑（时间/程度/类型）",
      "每项要简短有梗",
      "要有意外项（第X个你绝对想不到）",
      "最后要总结升华"
    ],
    avoidMistakes: [
      "不要超过7项（记不住）",
      "不要流水账",
      "不要缺少总结"
    ]
  },
  interview: {
    name: "采访型",
    formula: "人物介绍 → 核心问题 → 金句挖掘",
    coreLogic: "借他人之口输出价值",
    emotionCurve: "好奇 → 共鸣 → 启发",
    keyPoints: [
      "被访者要有身份标签",
      "问题要切中痛点",
      "要有1-2个金句",
      "采访要像聊天不像审问"
    ],
    avoidMistakes: [
      "不要选不会表达的人",
      "不要问太多问题",
      "不要让被访者念稿"
    ]
  },
  observe: {
    name: "观察型",
    formula: "现象观察 → 深度分析 → 启发思考",
    coreLogic: "从细节洞察人性",
    emotionCurve: "共鸣 → 恍然大悟 → 反思",
    keyPoints: [
      "观察要日常但被忽视",
      "分析要有深度有洞察",
      "要升华到人性或规律",
      "结尾要引发思考"
    ],
    avoidMistakes: [
      "不要观察太偏门的事",
      "不要停留在表面",
      "不要强行升华"
    ]
  },
  auto: {
    name: "AI智能推荐",
    formula: "根据主题和内容类型智能选择最合适的脚本结构",
    coreLogic: "综合分析选择最优结构",
    emotionCurve: "根据选择的结构动态调整",
    keyPoints: [
      "分析主题适合的脚本类型",
      "结合用户档案和定位",
      "选择最能体现价值的结构",
      "确保结构符合平台特性"
    ],
    avoidMistakes: [
      "不要选择过于复杂的结构",
      "不要忽视用户能力限制",
      "不要选择与内容类型冲突的结构"
    ]
  }
};

export interface StructureNarrative {
  /** 该结构适用于什么样的用户处境 */
  coreLogic: string;
  /** 情绪推进路径，用于指导波点设计 */
  emotionCurve: string;
}

/**
 * 取某个结构的核心逻辑与情绪曲线。
 *
 * 只返回 script-details 没有的两个字段：name/formula/keyPoints/avoidMistakes
 * 仍以 script-details 为准，避免两份数据各说各话。
 * 未知结构返回 null，由调用方决定是否省略这一段。
 */
export function getStructureNarrative(structureId: string): StructureNarrative | null {
  const d = (SCRIPT_STRUCTURE_DETAILS as Record<string, any>)[structureId];
  if (!d || !d.coreLogic || !d.emotionCurve) return null;
  return { coreLogic: d.coreLogic, emotionCurve: d.emotionCurve };
}