/**
 * 自动质检（2026-10-03）：每次生成完都体检一遍，记一笔，后台看板看趋势；每晚再拿固定档案回归一次。
 *
 * 查的都是这几天线上真出过的事，规则复用已有的扫描，不另起一套：
 * - taboo      踩禁忌（平台红线 + 行业禁忌词，lib/taboos 的 scanTaboos）
 * - excluded   漏出排除清单里的东西（建档时没选的，lib/interview-exclusions）
 * - mix        配比条数对不上（选题、方向按配比出时，lib/content-mix 的 checkMix）
 * - years      年限和人设事实卡打架（「南乐 18 年」那次：事实卡写半年，结果写 18 年）
 *
 * 纯函数：浏览器（实时体检）和服务器（每晚回归）共用。
 */
import { scanTaboos } from './taboos';
import { findExcludedMentions } from './interview-exclusions';
import { readTabooSettings } from './taboos';
import { readPersonaFacts } from './persona-facts';
import { checkMix, type ResolvedMix } from './content-mix';

export type QualityKind = 'taboo' | 'excluded' | 'mix' | 'years' | 'generation' | 'facts';

export const QUALITY_LABELS: Record<QualityKind, string> = {
  taboo: '踩禁忌',
  excluded: '用了排除的信息',
  mix: '配比对不上',
  years: '年限和人设事实卡不符',
  generation: '生成未完成或内容缺失',
  facts: '关键事实没有出处（价格、地点、资历、数据）',
};

/**
 * 关键事实核对（2026-10-04）：结果里出现的价格、地名、资历荣誉、"据统计"这类说法，档案和这次的素材里都找不到，就标出来请人核对。
 *
 * 只做"有没有出处"的比对，不判断真假：档案里写了 38 元、素材里有濮阳，结果照用就不报；
 * 模型自己编出来的"人均 68""开了 5 家分店""据统计 80% 的人"会报。
 * 局限：同义说法（"三十八块" vs "38 元"）、档案外但用户口头说过的事实会误报；它是提醒，不是事实核验系统。
 * 只查创作类板块：拆解是在分析别人的视频，出现原片里的价格地名是正常的。
 */
export const FACT_CHECK_TASKS = new Set(['脚本生成', '审稿优化', '分镜脚本', '标题封面', '开篇钩子', '跨行业二创', '选题策划']);

const CN_DIGIT: Record<string, number> = { 零: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
/** 「三十八」→ 38，认不出返回 null（够用就行：价格、分店数都在一百以内居多） */
function cnNumber(s: string): number | null {
  if (/^\d+(\.\d+)?$/.test(s)) return Number(s);
  const m = s.match(/^([一二两三四五六七八九])?(十)?([一二三四五六七八九])?$/);
  if (!m || (!m[1] && !m[2] && !m[3])) return null;
  if (!m[2]) return m[1] ? CN_DIGIT[m[1]] : CN_DIGIT[m[3]!];
  return (m[1] ? CN_DIGIT[m[1]] : 1) * 10 + (m[3] ? CN_DIGIT[m[3]] : 0);
}

const PRICE_RE = /(?:¥\s*(\d+(?:\.\d+)?)|(\d+(?:\.\d+)?|[一二两三四五六七八九十]{1,3})\s*(?:元|块钱|块(?![\p{L}])))/gu;
const PLACE_RE = /([\p{Script=Han}]{2,4})(?:市|县|区|镇|乡|村)(?![\p{Script=Han}]{0,1}(?:场|长|民|委|政府|级))/gu;
const HONOR_RE = /(?:(\d+|[一二两三四五六七八九十]{1,3})\s*家(?:分店|门店|连锁)|老字号|非遗|获奖|冠军|金奖|排名第一|销量第一|全网第一|全国第一|全市第一|百年老店)/g;
const STAT_RE = /(?:据[^，。！？\n]{0,10}(?:统计|调查|报告|数据)|数据显示|研究表明|调查显示|有数据(?:显示|表明)|权威机构)/g;
/** 这些"区"不是地名 */
const NOT_PLACE = /^(?:评论|弹幕|直播|后厨|用餐|就餐|等候|办公|休息|商|景|社|小|市|城|老城|新城|开发|功能|服务)$/;

export function unsupportedFacts(output: string, knownText: string): string[] {
  const known = knownText || '';
  const knownNumbers = new Set([...known.matchAll(/\d+(?:\.\d+)?|[一二两三四五六七八九十]{1,3}/g)].map((m) => cnNumber(m[0])).filter((n): n is number => n !== null));
  const out: string[] = [];
  const near = (at: number, len: number) => output.slice(Math.max(0, at - 8), at + len + 4).replace(/\s+/g, ' ').trim();
  for (const m of output.matchAll(PRICE_RE)) {
    const n = cnNumber(m[1] ?? m[2] ?? '');
    if (n === null || knownNumbers.has(n)) continue;
    out.push(`价格「${near(m.index ?? 0, m[0].length)}」档案和素材里都没有`);
  }
  for (const m of output.matchAll(PLACE_RE)) {
    const name = m[1];
    if (NOT_PLACE.test(name) || known.includes(name) || known.includes(name.slice(-2))) continue;
    out.push(`地名「${m[0]}」档案和素材里都没有`);
  }
  for (const m of output.matchAll(HONOR_RE)) {
    if (known.includes(m[0]) || (m[1] && knownNumbers.has(cnNumber(m[1]) ?? -1) && /分店|门店|连锁/.test(known))) continue;
    out.push(`资历/荣誉「${near(m.index ?? 0, m[0].length)}」档案里没有`);
  }
  if (!/来源[：:]|出处[：:]|https?:\/\//.test(output)) {
    for (const m of output.matchAll(STAT_RE)) out.push(`「${near(m.index ?? 0, m[0].length)}」引用了数据但没给出处`);
  }
  return Array.from(new Set(out)).slice(0, 5);
}

export interface QualityIssue {
  kind: QualityKind;
  /** 一句话说清是什么问题（给后台看） */
  detail: string;
}

export interface QualityResult {
  passed: boolean;
  issues: QualityIssue[];
}

/** 中文数字也认：十八 → 18、半 → 0.5 */
function toNumber(s: string): number | null {
  if (/^\d+(\.\d+)?$/.test(s)) return Number(s);
  if (s === '半') return 0.5;
  const map: Record<string, number> = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
  if (s === '十') return 10;
  const m = s.match(/^([一二两三四五六七八九])?十([一二三四五六七八九])?$/);
  if (m) return (m[1] ? map[m[1]] : 1) * 10 + (m[2] ? map[m[2]] : 0);
  return map[s] ?? null;
}

// 「年级、年代、年前、年后、年底、年轻、年龄……」里的年不是"干了几年"
const YEAR_RE = /(\d+(?:\.\d+)?|[一二两三四五六七八九十]{1,3}|半)\s*年(?!级|代|前|后|内|底|初|轻|纪|龄|度|份|货|会|终|中|头|夜|糕)/g;

/**
 * 年限打架：结果里"在本地 / 来 / 扎根 / 干了 / 做了 N 年"的 N，事实卡里一个都对不上。
 * 只看这几种说法附近的年数——"2026 年""一年四季"这种不算。
 */
export function yearConflicts(output: string, persona: unknown): string[] {
  const f = readPersonaFacts(persona);
  const factText = [f.yearsInTrade, f.yearsLocal, f.story, f.others].filter(Boolean).join(' ');
  if (!factText) return [];
  const numbers = (text: string) => new Set([...text.matchAll(YEAR_RE)].map(m => toNumber(m[1])).filter((n): n is number => n !== null && n < 1900));
  const known = numbers(factText);
  if (known.size === 0) return [];
  type Dimension = 'trade' | 'local' | 'store';
  const localPlace = (f.yearsLocal ?? '').match(/(?:来|在)([\p{L}]{2,6}?)(?=半|\d|[一二两三四五六七八九十]|定居|居住|扎根)/u)?.[1];
  const dimension = (before: string, after: string): Dimension | null => {
    if (/店龄|开店|开了|经营.{0,8}(?:店|门店)|(?:店|门店).{0,5}(?:开|经营)/.test(before) || /^\s*(?:的)?老店/.test(after)) return 'store';
    if (/本地|当地|扎根|定居|居住|落户|搬来|住了|待了|呆了|来[^，。！？；\n]{1,8}$/.test(before)) return 'local';
    if (localPlace && before.includes(localPlace) && /在/.test(before) && !/经验|从业|这行|厨师|做菜|川菜|家具行业/.test(before)) return 'local';
    if (/从业|入行|这行|厨师|做菜|川菜|粤菜|手艺|经验|干了|做了|做.{0,6}(?:菜|餐饮|美甲|家具)/.test(before) || /^\s*(?:的)?(?:经验|手艺)/.test(after)) return 'trade';
    return null;
  };
  const allowed: Record<Dimension, Set<number>> = { trade: numbers(f.yearsInTrade ?? ''), local: numbers(f.yearsLocal ?? ''), store: new Set() };
  // 自由事实里的年数也按语义归类，不能把从业年数借给店龄或居住年限。
  for (const text of [f.story, f.others].filter((x): x is string => !!x)) for (const m of text.matchAll(YEAR_RE)) {
    const at = m.index ?? 0;
    const before = text.slice(0, at).split(/[，。！？；\n]/).pop()!.slice(-20);
    const d = dimension(before, text.slice(at + m[0].length, at + m[0].length + 8));
    const n = toNumber(m[1]);
    if (d && n !== null && (d === 'store' || (d === 'trade' ? !f.yearsInTrade : !f.yearsLocal))) allowed[d].add(n);
  }
  const out: string[] = [];
  for (const m of output.matchAll(YEAR_RE)) {
    const n = toNumber(m[1]);
    if (n === null || n >= 1900) continue;
    const at = m.index ?? 0;
    const before = output.slice(0, at).split(/[，。！？；\n]/).pop()!.slice(-20);
    const after = output.slice(at + m[0].length, at + m[0].length + 8);
    // 说的是"在本地 / 干这行多久"才算：在南乐扎根 18 年、做了 8 年、18 年了、18 年的老店
    const d = dimension(before, after);
    const aboutTenure = !!d || /在|变了/.test(before) || /^\s*(?:了|的老店|老店|的经验|经验|的手艺)/.test(after);
    if (!aboutTenure) continue;
    if (d ? allowed[d].has(n) : known.has(n)) continue;
    out.push(output.slice(Math.max(0, at - 10), at + m[0].length + 3).replace(/\s+/g, ' ').trim());
  }
  return Array.from(new Set(out)).slice(0, 5);
}

/** 审稿只检查明确交付的改写稿；诊断中引用的错误原文不是交付内容。 */
export function reviewedQualityOutput(answer: string): string {
  const lines = answer.split('\n');
  const start = lines.findIndex(line => /^\s*#{1,4}\s+/.test(line) && /(?:优化|修改|改写)后的(?:完整)?(?:脚本|文案)|优化稿|最终稿/.test(line));
  if (start < 0) return '';
  const level = lines[start].match(/^\s*(#+)/)![1].length;
  let end = lines.length;
  for (let i = start + 1; i < lines.length; i++) {
    const heading = lines[i].match(/^\s*(#{1,4})\s+(.*)$/);
    if (heading && heading[1].length <= level && !/^[^\p{L}\p{N}]*【/u.test(heading[2])) { end = i; break; }
  }
  return lines.slice(start + 1, end).join('\n').trim();
}

export function runQualityChecks(p: {
  output: string;
  profile: object | null | undefined;
  taskType?: string;
  /** 按配比出的选题、方向：要求的配比和条数 */
  mix?: { resolved: ResolvedMix; count: number } | null;
  /** 这次带进来的素材（源资料、原稿）：结果里的价格、地名在这里找得到就不算编的 */
  source?: string | null;
}): QualityResult {
  const issues: QualityIssue[] = [];
  const profile = (p.profile ?? null) as Record<string, unknown> | null;
  const reviewed = reviewedQualityOutput(p.output);
  const output = p.taskType && /审稿|review/i.test(p.taskType) ? reviewed : reviewed && /问题清单|审稿|修改建议/.test(p.output) ? reviewed : p.output;
  if (!/[\p{L}\p{N}]/u.test(output ?? '')) {
    return { passed: false, issues: [{ kind: 'generation', detail: p.taskType && /审稿|review/i.test(p.taskType) ? '未找到优化后的脚本正文，无法完成质检' : '未收到有效正文，不能判为通过' }] };
  }

  for (const h of scanTaboos(output, profile).slice(0, 5)) {
    issues.push({ kind: 'taboo', detail: `「${h.word}」— ${h.taboo.why}` });
  }
  const excluded = readTabooSettings(profile?.taboo_settings).excluded;
  for (const h of findExcludedMentions(output, excluded, String(profile?.profile_name ?? '')).slice(0, 5)) {
    issues.push({ kind: 'excluded', detail: `提到了「${h.needle}」：${h.line}` });
  }
  if (p.mix) {
    const c = checkMix(output, p.mix.resolved, p.mix.count);
    if (!c.ok) issues.push({ kind: 'mix', detail: c.counted ? `实际 ${c.summary}，要求 ${c.expected}${c.got.unknown ? `，${c.got.unknown} 条没标目的` : ''}` : '未识别到要求的选题或方向条目，无法确认配比' });
  }
  for (const y of yearConflicts(output, profile?.persona_facts)) {
    issues.push({ kind: 'years', detail: `「${y}」和事实卡对不上` });
  }
  // 关键事实：只在有档案时查（没档案就没有可比对的事实），只查创作类板块
  if (profile && p.taskType && FACT_CHECK_TASKS.has(p.taskType)) {
    for (const f of unsupportedFacts(output, `${JSON.stringify(profile)}\n${p.source ?? ''}`)) issues.push({ kind: 'facts', detail: f });
  }
  return { passed: issues.length === 0, issues };
}

const KINDS = Object.keys(QUALITY_LABELS) as QualityKind[];

/** 上报的体检结果校验一遍再入库（请求来自浏览器，不能原样信） */
export function sanitizeQualityReport(v: unknown): { task_type: string; profile_id: string | null; passed: boolean; issues: QualityIssue[]; sample: string } | null {
  if (!v || typeof v !== 'object') return null;
  const o = v as Record<string, unknown>;
  const task = typeof o.taskType === 'string' ? o.taskType.trim().slice(0, 40) : '';
  if (!task) return null;
  const issues = (Array.isArray(o.issues) ? o.issues : [])
    .filter((x): x is Record<string, unknown> => !!x && typeof x === 'object' && KINDS.includes((x as Record<string, unknown>).kind as QualityKind))
    .slice(0, 20)
    .map((x) => ({ kind: x.kind as QualityKind, detail: String(x.detail ?? '').slice(0, 200) }));
  const profileId = typeof o.profileId === 'string' && /^[0-9a-f-]{36}$/i.test(o.profileId) ? o.profileId : null;
  return { task_type: task, profile_id: profileId, passed: issues.length === 0, issues, sample: typeof o.sample === 'string' ? o.sample.slice(0, 300) : '' };
}

export interface QualityRow { task_type: string; source: string; passed: boolean; issues: QualityIssue[]; sample?: string | null; created_at: string }

/** 后台看板的汇总：通过率、哪个板块问题多、最常见的问题、最近不合格的样例、最近一次每晚回归 */
export function summarizeQuality(rows: QualityRow[]) {
  const live = rows.filter((r) => r.source === 'live');
  const failed = live.filter((r) => !r.passed);
  const byTask = new Map<string, { task: string; total: number; failed: number }>();
  for (const r of live) {
    const t = byTask.get(r.task_type) ?? { task: r.task_type, total: 0, failed: 0 };
    t.total++;
    if (!r.passed) t.failed++;
    byTask.set(r.task_type, t);
  }
  const byKind = new Map<QualityKind, number>();
  for (const r of failed) for (const k of new Set(r.issues.map((i) => i.kind))) byKind.set(k, (byKind.get(k) ?? 0) + 1);
  const nightly = rows.filter((r) => r.source === 'nightly').sort((a, b) => b.created_at.localeCompare(a.created_at));
  const lastNight = nightly[0]?.created_at.slice(0, 10);
  return {
    total: live.length,
    failed: failed.length,
    passRate: live.length ? Math.round(((live.length - failed.length) / live.length) * 1000) / 10 : null,
    byTask: [...byTask.values()].sort((a, b) => b.failed - a.failed || b.total - a.total),
    byKind: [...byKind.entries()].map(([kind, count]) => ({ kind, label: QUALITY_LABELS[kind], count })).sort((a, b) => b.count - a.count),
    recentFailures: failed.sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 15),
    nightly: lastNight ? nightly.filter((r) => r.created_at.slice(0, 10) === lastNight) : [],
  };
}

/** 同一份结果只报一次（刷新、切回来恢复的不算新生成） */
export function outputKey(text: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return `${text.length}:${h.toString(16)}`;
}
