"use client";

import {
  useState, useEffect } from "react";
import Link from "next/link";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { SUBSCRIPTION_PLANS, quotaSummary, planSellingPoints } from "@/lib/config/plans";
import { SHOWCASE_TACTICS, SHOWCASE_CARDS, SHOWCASE_STRUCTURES, FACTS } from "@/lib/showcase";
import { VIRAL_ELEMENTS, SCRIPT_FAMILIES } from "@/lib/viral-elements";
import { LandingNavCTA } from "@/components/landing/LandingNavCTA";
import { TryHero } from "@/components/landing/hero/TryHero";
import { REGISTER_URL } from "@/lib/landing";
import { DEAL_REASONS } from "@/lib/deal-reasons";
import { PURPOSES } from "@/lib/direction";
import { LIBRARY_CATEGORIES } from "@/lib/library";
import { BRAND_NAME, BrandSeal, BrandWordmark } from "@/components/brand/Brand";
import { 
  Zap, CheckCircle, TrendingUp, ArrowRight, 
  FileText, Lightbulb, Film, Target, Star,
  Crown, Check, BarChart3, Award, BookOpen,
  Brain, Layers, Clock, Shield, Quote, ChevronRight,
  MessageCircle, Activity, ChevronDown, X,
  Clapperboard, Shuffle, FileSearch, GraduationCap, Compass, Bookmark, ListChecks, MessagesSquare,
} from "lucide-react";

export default function HomePage() {
  /**
   * 落地页的三个大数字。
   *
   * 原来是编的（接口里写着「返回合理的假数据」，失败时前端还会退回
   * 1280/15680/98 这组写死的数），并以「创作者正在使用」的名义展示。
   * 现在只认接口给的真实数；接口给 null 就那一项不显示——
   * 宁可少一块，也不编一个。
   */
  const [stats, setStats] = useState<{
    users: number | null;
    scripts: number | null;
    methods: number | null;
  }>({ users: null, scripts: null, methods: null });
  const [mounted, setMounted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    setMounted(true);
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const res = await fetch('/api/public/stats');
      if (!res.ok) return;
      const data = await res.json();
      animateNumbers({
        users: typeof data.users === 'number' ? data.users : null,
        scripts: typeof data.scripts === 'number' ? data.scripts : null,
        methods: typeof data.methods === 'number' ? data.methods : null,
      });
    } catch {
      // 拿不到就保持 null，那几块不显示。不再退回写死的假数
    }
  };

  const animateNumbers = (target: {
    users: number | null;
    scripts: number | null;
    methods: number | null;
  }) => {
    const steps = 60;
    const duration = 2000;
    // null 的那项全程保持 null，不参与动画，否则会从 0 跳一下再消失
    const step = (v: number | null, i: number) =>
      v === null ? null : Math.floor((v / steps) * i);

    let current = 0;
    const timer = setInterval(() => {
      current++;
      setStats({
        users: step(target.users, current),
        scripts: step(target.scripts, current),
        methods: step(target.methods, current),
      });
      if (current >= steps) {
        clearInterval(timer);
        setStats(target);
      }
    }, duration / steps);
  };

  if (!mounted) return null;

  const features = [
    {
      icon: Target,
      title: "账号定位",
      desc: "先出核心几节让你尽快看到方向，再补完整方案",
      benefits: ["避免试错成本", "精准人设定位", "商业模式规划"],
      color: "blue"
    },
    {
      icon: Lightbulb,
      title: "选题策划",
      /*
       * 原来写「AI实时分析热点趋势」「每日热点追踪」「爆款概率预测」。
       * 系统没有任何热点数据源，提示词里只是让模型"结合当前热点"——
       * 那是模型自己训练时的旧知识，谈不上实时；"概率预测"更是完全没有。
       * 改成真正在做的事：按八大爆款元素的句式出题、可填对标账号、每条带钩子。
       */
      desc: "按八大爆款元素的句式出选题，贴着你的账号定位",
      benefits: ["八大爆款元素句式", "对标账号参考", "每条附开篇钩子"],
      color: "yellow"
    },
    {
      icon: FileText,
      title: "脚本生成",
      // 「多版本对比」「一键多版本」没有做——只能重新生成、在历史里翻旧版
      desc: `AI 生成完整脚本，${FACTS.structures} 种脚本结构任选`,
      benefits: ["AI 智能生成", "内置编导知识库", `${FACTS.structures}种脚本结构`],
      color: "green"
    },
    {
      icon: Film,
      title: "分镜脚本",
      desc: "镜头表与拍摄清单，拍摄执行一目了然",
      benefits: ["镜头语言规划", "场景道具清单", "时长节奏把控"],
      color: "purple"
    },
    {
      icon: CheckCircle,
      title: "审稿优化",
      desc: "智能优化脚本节奏、情绪曲线、冲突设计",
      benefits: ["完播率优化", "情绪起伏分析", "冲突点强化"],
      color: "pink"
    },
    {
      icon: Zap,
      title: "标题与封面文案",
      // 生成数量可选 3/5/8/10，默认 5，所以说"最多"
      desc: "一次最多出 10 个标题+封面文案，方便 A/B 测试",
      benefits: ["标题公式库", "情绪钩子植入", "A/B测试建议"],
      color: "orange"
    },
    {
      icon: TrendingUp,
      // 板块本名是「成交理由」，原来这里写"成交话术"，点进去对不上
      title: "成交理由",
      desc: "找出客人凭什么选你，同步进账号档案，选题、脚本、标题都会用上",
      // 理由个数从理由表取，别手写（手写过"十五个"，实际 17 个）
      benefits: [`${DEAL_REASONS.length} 个成交理由逐个打分`, "按档案分别保存", "选题、脚本、标题和二创共用"],
      color: "red"
    },
    {
      icon: BookOpen,
      title: "知识库查询",
      // 不写「随时查阅」——知识库现在只有企业版无限，其余档位按次计费，
      // 「随时」就成了一句兑现不了的话
      desc: `约 ${FACTS.wordsWan} 万字符编导资料，分 ${FACTS.libraries} 个专题库，问一句就能查`,
      benefits: ["五个专题分库", "起号36+1计", "开篇36计"],
      color: "indigo"
    },
    /*
     * 2026-09-29/30 新上的四个。产品方："新上的功能首页没有的，同步到首页"。
     * 说的都是真做到的事（见各板块的实现），不写做不到的。
     */
    {
      // 2026-10-02 新上
      icon: Compass,
      title: "创作方向",
      desc: "告诉 AI 你拍视频是为了什么，按你的账号铺开方向和思路，推荐最值得先做的一个",
      benefits: [`${PURPOSES.length} 种目的可选`, "勾选方向直接去写", "推荐先做哪个"],
      color: "orange",
      isNew: true,
    },
    {
      icon: Clapperboard,
      title: "拆解爆款",
      desc: "传一条参考视频，结合画面与口播拆出开篇、结构和拍法",
      benefits: ["前3分钟切镜头、截图", "口播自动识别", "拆解卡片与档案历史"],
      color: "purple",
      isNew: true,
    },
    {
      icon: Shuffle,
      title: "跨行业二创",
      desc: "借别的行业爆款的开篇、结构、拍法，换成你自己的行业来拍",
      benefits: ["11 个层次自由选", "拆解完一键带过来", "改写自查与档案历史"],
      color: "green",
      isNew: true,
    },
    {
      icon: FileSearch,
      title: "前采建档",
      desc: "贴前采记录或传 Word，AI 提取成账号档案，逐项核对后再写入",
      benefits: ["每项标原文依据", "AI 逐项核对", "补问清单"],
      color: "blue",
      isNew: true,
    },
    {
      icon: GraduationCap,
      title: "新手课堂",
      desc: "6 关学会抖音怎么推荐、怎么拍、怎么发，完全不懂也能上手",
      benefits: ["刷视频式学习", "每关一道题", "毕业接 7 天起号"],
      color: "yellow",
      isNew: true,
    },
    /*
     * 2026-10-02 新上的三个（产品方："把所有新上的功能同步到工作台首页和宣传页"）。
     * 高阶自由对话原来压根没有卡片；联网、六附件、勾选带走都是真做到的（见 lib/web-query、
     * Dify 文件上传上限 6、components/workspace/CreationLinks）
     */
    {
      icon: MessagesSquare,
      title: "高阶自由对话",
      desc: "什么都能问：按需联网查最新信息，读图片和文档；回答里的选题、方向、脚本能勾选带去接着做",
      benefits: ["联网结果标来源链接", "一次最多 6 个附件", "回答可勾选、可收藏"],
      color: "blue",
      isNew: true,
    },
    {
      icon: Bookmark,
      title: "素材库",
      desc: "任何板块生成的好内容一键收藏，按选题、脚本、方向思路等分类，随时拿去继续创作",
      benefits: ["勾几条存几条", `${LIBRARY_CATEGORIES.length} 个分类`, "一键继续创作"],
      color: "pink",
      isNew: true,
    },
    {
      icon: ListChecks,
      title: "创作进度",
      desc: "每条内容做到哪一步、拍没拍、发没发，一眼看清；做好没拍、拍完没发会提醒",
      benefits: ["选题到标题逐环节", "还没拍 / 已拍摄 / 已发布", "多久没动会提醒"],
      color: "indigo",
      isNew: true,
    },
  ];

  /*
   * 价格与额度全部从 lib/config/plans.ts 派生。
   *
   * 这里原本手写着一份，和代码、会员页、收款页三处都对不上：
   * 免费版写「账号定位 3次」（实际 1 次）、企业版写 199（收款页收 599）。
   * 首页是对外公示的价格，它和实际收款必须来自同一个源头。
   */
  const pricingPlans = [
    {
      name: SUBSCRIPTION_PLANS.free.name,
      price: SUBSCRIPTION_PLANS.free.price,
      period: "一次性体验",
      desc: "体验核心功能",
      features: quotaSummary("free"),
      highlight: false,
      cta: "立即开始"
    },
    {
      name: SUBSCRIPTION_PLANS.basic.name,
      price: SUBSCRIPTION_PLANS.basic.price,
      period: "月",
      desc: "适合个人创作者",
      // 权益只从 planSellingPoints 取。这里原来手写着「邮件客服支持」——
      // 那个邮箱根本不存在，早先已经确认过
      features: [...quotaSummary("basic"), ...planSellingPoints("basic")],
      highlight: false,
      cta: "选择基础版"
    },
    {
      name: SUBSCRIPTION_PLANS.pro.name,
      price: SUBSCRIPTION_PLANS.pro.price,
      period: "月",
      desc: "适合专业团队",
      // 原来还写着「最高优先级」「多版本对比」「专属客服支持」，都没有做
      features: [...quotaSummary("pro"), ...planSellingPoints("pro")],
      highlight: true,
      cta: "选择专业版"
    },
    {
      name: SUBSCRIPTION_PLANS.enterprise.name,
      price: SUBSCRIPTION_PLANS.enterprise.price,
      period: "月",
      desc: "适合MCN机构",
      /*
       * 原来这里卖着「数据报表分析」「团队协作功能」「1v1专属顾问」——前两个
       * 代码里一行都没有，第三个本人确认做不到。「多账号档案切换」倒是做了，
       * 但所有档位都能用，当成企业版专属卖也是说错。
       */
      features: [...quotaSummary("enterprise"), ...planSellingPoints("enterprise")],
      highlight: false,
      cta: "选择高频会员"
    }
  ];

  const faqs = [
    {
      q: "完全不懂编导可以用吗？",
      a: `完全可以！${BRAND_NAME}内置 ${FACTS.docs} 篇、约 ${FACTS.wordsWan} 万字符的专业编导资料，AI会结合您的需求和账号档案生成内容。无论您是新手还是专业编导，都可以从行业样例开始，逐步写出选题、脚本与镜头方案。`
    },
    {
      q: "生成的脚本质量如何？",
      a: `我们用 AI 智能生成，结合内置的编导知识库和 ${FACTS.methods} 条公式与句式（起号 ${FACTS.tactics} 计、开篇 ${FACTS.cards} 计、脚本结构 ${FACTS.structures} 种、爆款元素 ${FACTS.elements} 类）。脚本按所选结构展开，可结合拍摄条件继续细化；分镜板块提供镜头、动作与时长方案。不满意可以重新生成，已保存的结果在云端历史中查看，拆解报告和二创方案也按档案保存。`
    },
    {
      q: "和其他AI工具有什么区别？",
      a: `核心优势在于：①约 ${FACTS.wordsWan} 万字符的专业编导资料（${FACTS.docs} 篇，${FACTS.libraries} 个专题分库）；②${FACTS.methods} 条公式与句式——四大脚本各对一个生意目的，起号 ${FACTS.tactics} 计、开篇 ${FACTS.cards} 计、脚本结构 ${FACTS.structures} 种、爆款元素 ${FACTS.elements} 类，其中脚本结构附情绪曲线与避坑说明；③${FACTS.boards} 个创作板块互通：任何板块的结果都能勾选几条带去别的板块，自动填好接着做；④结合账号档案组织创作背景，好内容可收藏进素材库，创作进度记着每条做到哪一步、拍没拍发没发。`
    },
    {
      // 2026-10-02：板块互通、素材库、创作进度上线后加
      q: "生成的内容怎么接着用？",
      a: "每个板块的结果下面都有「继续创作」：结果里有好几条选题、方向或脚本时，先勾要的那几条，再点想去的板块（写脚本、拆分镜、起标题……），内容自动填好，点生成就行。好的内容点「收藏」存进素材库，按分类随时取用；每条内容做到哪一步、拍没拍、发没发，在「创作进度」里一目了然。"
    },
    {
      q: "免费版有什么限制？",
      /*
       * 这一行原来是手写的「每月 50 次（账号定位3次、选题3次、脚本20次、对话20次）」，
       * 四个数字里有三个和 lib/config/plans.ts 对不上，总数 50 也是凑的。
       * 价格页早就改成从配置现算了，只有这里还留着一份手写的。
       * 直接用 quotaSummary，配置改了这里自动跟。
       */
      a: `免费版的额度是：${quotaSummary("free").join("、")}。核心创作板块均可体验，主要区别是次数。账号定位、商业定位、内容定位与创作简报共享定位额度；脚本生成、起号方案与开篇钩子共享脚本额度。`
    },
    {
      q: "如何保证数据安全？",
      a: "数据存放在 Supabase（Postgres），按账号进行权限隔离。已保存的历史可查看、复制和删除；拆解报告和二创方案按档案保存，未主动删除就持续保留。生成与视频处理会使用第三方服务，具体处理范围请查看隐私政策。"
    },
    {
      q: "可以开发票吗？",
      a: "目前还不支持开发票。有开票需求请先联系我们再决定是否购买，避免付完款才发现开不了。"
    },
    {
      q: "支持哪些支付方式？",
      a: "微信和支付宝转账，扫码付款后上传转账截图，我核对后开通。"
    },
    {
      q: "如何联系客服？",
      a: "直接加微信：13240286600（手机同号）。目前是我本人在对接，看到就回。"
    }
  ];

  const colorClasses: Record<string, string> = {
    blue: "bg-primary/15 dark:bg-blue-900/30 text-primary",
    yellow: "bg-amber-500/15 dark:bg-yellow-900/30 text-yellow-500",
    green: "bg-emerald-500/15 dark:bg-green-900/30 text-green-500",
    purple: "bg-accent/15 dark:bg-purple-900/30 text-accent",
    pink: "bg-accent/15 dark:bg-pink-900/30 text-accent",
    orange: "bg-amber-500/15 dark:bg-orange-900/30 text-orange-500",
    red: "bg-destructive/15 dark:bg-red-900/30 text-destructive",
    indigo: "bg-primary/15 dark:bg-indigo-900/30 text-primary"
  };


  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <header className="fixed top-0 w-full border-b border-border bg-white/80 dark:bg-muted/80 backdrop-blur-xl z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          {/* 窄屏（320 宽）时顶栏放不下会把"开物""登录""免费试用"都折成两行：字不许折行，间距收紧 */}
          <Link href="/" className="flex shrink-0 items-center gap-2 whitespace-nowrap transition-opacity hover:opacity-90 sm:gap-2.5">
            <BrandSeal size={32} />
            <span className="hidden text-[21px] text-foreground min-[360px]:inline">
              <BrandWordmark />
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">核心功能</a>
            <a href="#advantages" className="text-sm font-medium hover:text-primary transition-colors">核心优势</a>
            {/* 原来是「成功案例」指向 #cases，而页面上根本没有这个版块——点了不会有
                任何反应。而且我们手上没有可公开的真实客户案例，编一个就是另一种形式的
                假数据。换成真正能说服人、也抄不走的东西：方法本身 */}
            <a href="#method" className="text-sm font-medium hover:text-primary transition-colors">编导方法</a>
            <a href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">价格方案</a>
          </nav>
          <div className="flex items-center gap-2 whitespace-nowrap sm:gap-4">
            <ThemeToggle />
            <LandingNavCTA />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden bg-primary/10">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute top-40 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{animationDelay:'1s'}} />
          <div className="absolute bottom-20 left-1/3 w-80 h-80 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{animationDelay:'2s'}} />
        </div>

        {/*
          首屏「一句话开始」（产品方从三个版本里选的）：给完全不懂的小白。
          原来的首屏是"AI编导助手 · 专业编导知识库 · Claude AI 驱动"——
          说的是我们是谁，小白不知道"编导"是什么，也不在乎知识库多少字。
          现在标题讲他能得到什么，首屏第一个动作是"就在这儿试"，看完再注册。
          方法库、知识库这些给懂行的人看的，挪到下面几屏。
        */}
        <div className="container mx-auto relative z-10">
          <TryHero />
        </div>
      </section>

      {/*
        Stats。
        以前这里是编的（1280 创作者 / 15680 脚本 / 98% 满意度），清掉之后换成了
        真实数字，但「累计生成内容 168」这种说法是在拿我们最弱的一面当门面——
        一个刚起步的产品，用量天然不好看，而且那根本不是我们的优势。

        改成讲**结构性的东西**：方法成体系、全流程打通、知识库是真的编导知识。
        这几条不随用量涨跌，也是通用 AI 给不了的。
        每一条都必须为真——数字统一从 lib/showcase.ts 的 FACTS 取。
      */}
      {(() => {
        const tiles = [
          {
            key: 'methods',
            value: FACTS.methods,
            label: '条带公式的方法',
            sub: `四大脚本 · 八大爆款元素 · 起号 ${FACTS.tactics} 计 · 开篇 ${FACTS.cards} 计 · 脚本结构 ${FACTS.structures} 种，结构附情绪曲线与避坑说明`,
            suffix: '',
          },
          {
            /*
             * 这一格原来是「5 步全流程打通」。5 是这三个数里最小的一个，
             * 摆在中间反而把整排数据压下去了，而且"5 步"听上去像流程图，
             * 不像资产。换成知识库全文字符数，数字由 FACTS 统一维护，
             * 也是通用 AI 最给不出来的东西。
             */
            key: 'words',
            value: FACTS.wordsWan,
            label: '万字符专业编导资料',
            sub: `${FACTS.docs} 篇 · ${FACTS.libraries} 个专题分库，全文统计含标点与排版字符`,
            suffix: '',
          },
          {
            key: 'boards',
            value: FACTS.boards,
            label: '个创作板块，互通互联',
            sub: `${FACTS.pipeline.join(' → ')}，每一步结果都能带去下一步`,
            suffix: '',
          },
        ].filter((t) => typeof t.value === 'number' && t.value > 0);

        if (tiles.length === 0) return null;

        return (
          <section className="py-16 bg-white/50 dark:bg-muted/50 backdrop-blur-xl border-y border-border/40">
            <div className="container mx-auto px-4">
              <div
                className={`grid grid-cols-1 gap-8 max-w-4xl mx-auto ${
                  tiles.length >= 3 ? 'md:grid-cols-3' : tiles.length === 2 ? 'md:grid-cols-2' : ''
                }`}
              >
                {tiles.map((t) => (
                  <div key={t.key} className="text-center group hover:scale-105 transition-transform">
                    <div className="text-4xl sm:text-5xl md:text-6xl font-extrabold brand-gradient bg-clip-text text-transparent mb-2">
                      {(t.value as number).toLocaleString()}
                      {t.suffix}
                    </div>
                    <div className="text-sm text-foreground font-medium">{t.label}</div>
                    {/* 副标题是关键：光一个数字说明不了优势，得说清这个数字意味着什么 */}
                    <div className="mt-1.5 text-[12px] leading-relaxed text-muted-foreground">
                      {t.sub}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        );
      })()}

      {/* 三大核心优势 */}
      <section id="advantages" className="py-20 px-4 bg-primary/10">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/15 dark:bg-purple-900/30 rounded-full mb-4">
              <Crown className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">为什么选择我们</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="brand-gradient bg-clip-text text-transparent">三大核心优势</span>
            </h2>
            <p className="text-xl text-muted-foreground dark:text-foreground max-w-2xl mx-auto">专业编导知识 + AI技术 + 持续迭代，让您的创作始终领先一步</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur-xl opacity-0 group-hover:opacity-20 transition-opacity" />
              <div className="relative glass-panel rounded-2xl p-8 border-2 border-border hover:border-primary/40 transition-all hover:shadow-2xl h-full">
                <div className="w-16 h-16 bg-primary/15 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <BookOpen className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4">约 {FACTS.wordsWan} 万字符编导资料</h3>
                {/*
                  原来写「150+ 篇、73 个方法」。两个数都把自己说小了：
                  现数是 153 篇、约 29.6 万全文字符，方法包含 19 种脚本结构。
                  数字一律从 FACTS 取，那里每一个都有测试对着源头现数。
                */}
                <p className="text-muted-foreground dark:text-foreground mb-6">
                  <span className="font-semibold text-primary">约 {FACTS.wordsWan} 万字符</span>、
                  <span className="font-semibold text-primary">{FACTS.docs}</span> 篇专业编导资料，
                  拆成 <span className="font-semibold text-primary">{FACTS.libraries}</span> 个专题分库，
                  提炼出 <span className="font-semibold text-primary">{FACTS.methods}</span> 条带公式的方法
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">四大脚本（教知识/聊观点/晒过程/讲故事）各对一个生意目的</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">八大爆款元素、起号 {FACTS.tactics} 计、开篇 {FACTS.cards} 计、脚本结构 {FACTS.structures} 种</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">公式与句式可套用，脚本结构附情绪曲线与避坑说明</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">来自成体系的编导课程，不是网上抓的碎片</span></li>
                </ul>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 brand-gradient rounded-2xl blur-xl opacity-0 group-hover:opacity-20 transition-opacity" />
              <div className="relative glass-panel rounded-2xl p-8 border-2 border-border hover:border-accent/40 transition-all hover:shadow-2xl h-full">
                <div className="w-16 h-16 bg-accent/15 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Brain className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold mb-4">AI 智能生成</h3>
                <p className="text-muted-foreground dark:text-foreground mb-6">
                  <span className="font-semibold text-accent">AI 智能生成</span>，
                  结合编导知识库，智能理解您的需求，生成专业级脚本
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">结合账号档案，自动生成完整脚本</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">脚本结构可选，也可让 AI 推荐</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">不满意就重新生成，历次结果都存在云端</span></li>
                </ul>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-orange-600 rounded-2xl blur-xl opacity-0 group-hover:opacity-20 transition-opacity" />
              <div className="relative glass-panel rounded-2xl p-8 border-2 border-border hover:border-accent/40 transition-all hover:shadow-2xl h-full">
                <div className="w-16 h-16 bg-accent/15 dark:bg-pink-900/30 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Layers className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{FACTS.boards} 个板块协同创作</h3>
                {/* 2026-10-02 更新：板块之间已经全通（勾选带走、自动填好），加了素材库和创作进度 */}
                <p className="text-muted-foreground dark:text-foreground mb-6">
                  从创作方向、账号定位到拍摄发布，覆盖短视频创作的<span className="font-semibold text-accent">主要环节</span>，
                  板块之间互通，内容自动带入
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">任何板块的结果都能勾选几条，带去别的板块接着做，自动填好</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">好内容一键收藏进素材库，按选题、脚本、方向思路分类取用</span></li>
                  <li className="flex items-start gap-2"><Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" /><span className="text-sm">创作进度记着每条做到哪一步、拍没拍、发没发</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>


      {/*
        编导方法库。
        取代原来那个指向空锚点的「成功案例」——我们没有可公开的真实客户案例，
        编一个就是另一种形式的假数据。而这一段展示的是**抄不走也编不出来**的
        东西：每一计都有名字、机制、结构公式和适用范围。
        别家能说"AI 帮你写脚本"，说不出"这是第 22 计行业避坑，
        结构是 点名坑 → 后果 → 识别信号 → 替代方案"。

        内容来自 lib/showcase.ts，那里的每一条都有测试盯着，和真实方法库逐字段比对。
      */}
      <section id="method" className="py-20 px-4 bg-muted/40 dark:bg-muted/20">
        <div className="container mx-auto">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/15 dark:bg-blue-900/30 rounded-full mb-4">
              <BookOpen className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">这是我们和通用 AI 的区别</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="brand-gradient bg-clip-text text-transparent">拍法是有公式的</span>
            </h2>
            <p className="text-xl text-muted-foreground dark:text-foreground max-w-3xl mx-auto">
              结合编导方法，给你<span className="font-semibold text-primary">一套能照着拍的结构</span>。
              四大脚本、八大爆款元素、起号 {FACTS.tactics} 计、开篇 {FACTS.cards} 计、
              脚本结构 {FACTS.structures} 种，共 <span className="font-semibold text-primary">{FACTS.methods} 条</span>，
              含可套用的公式与句式，脚本结构另附情绪曲线、适用场景，以及
              <span className="font-semibold text-primary">避坑说明</span>。
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            {/*
              四大脚本放在最前面，因为它是这套方法的骨架。
              它真正的卖点不是"分了四类"，而是**四类各对应一个生意目的**——
              通用 AI 问你"想要什么风格"，这套东西问的是"你这条是要涨粉、
              要粉丝更铁、要促变现，还是要成交高客单"。目的定了结构才定得下来。
            */}
            <h3 className="text-sm font-semibold tracking-widest text-muted-foreground mb-4">
              四大脚本 · 各对一个生意目的
            </h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
              {SCRIPT_FAMILIES.map((f) => (
                <div
                  key={f.name}
                  className="glass-panel rounded-2xl p-5 border-2 border-border hover:border-amber-500/40 transition-colors"
                >
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-lg font-bold">{f.name}</span>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-500 font-medium">
                      {f.purpose}
                    </span>
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">{f.note}</p>
                </div>
              ))}
            </div>

            <h3 className="text-sm font-semibold tracking-widest text-muted-foreground mb-4">
              起号 {FACTS.tactics} 计 · 摘三条
            </h3>
            <div className="grid md:grid-cols-3 gap-5 mb-12">
              {SHOWCASE_TACTICS.map((t) => (
                <div key={t.no} className="glass-panel rounded-2xl p-6 border-2 border-border hover:border-primary/40 transition-colors">
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-xs font-mono text-primary/70">第 {t.no} 计</span>
                    <span className="text-lg font-bold">{t.name}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{t.mechanism}</p>
                  {/* 结构公式是这套东西最有说服力的部分，单独框出来 */}
                  <div className="rounded-xl bg-primary/[0.07] border border-primary/20 px-3 py-2.5 mb-3">
                    {/* 实测：/70 透明度下 10px 小字对比度只有 3.06，低于可读标准，改用实色并加大一号 */}
                    <div className="text-[11px] font-medium tracking-wider text-primary mb-1">结构公式</div>
                    <div className="text-[13px] font-medium text-foreground">{t.formula}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">适合：{t.fit}</div>
                </div>
              ))}
            </div>

            <h3 className="text-sm font-semibold tracking-widest text-muted-foreground mb-4">
              开篇 {FACTS.cards} 计 · 分 {FACTS.cardCategories} 大类 · 摘三张
            </h3>
            <div className="grid md:grid-cols-3 gap-5 mb-12">
              {SHOWCASE_CARDS.map((c) => (
                <div key={c.no} className="glass-panel rounded-2xl p-6 border-2 border-border hover:border-accent/40 transition-colors">
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-lg font-bold">{c.name}</span>
                    <span className="text-[11px] px-2 py-0.5 rounded-md bg-accent/15 text-accent">{c.category}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{c.psychology}</p>
                  <div className="rounded-xl bg-accent/[0.07] border border-accent/20 px-3 py-2.5">
                    <div className="text-[11px] font-medium tracking-wider text-accent mb-1">开篇公式</div>
                    <div className="text-[13px] font-medium text-foreground">{c.formula}</div>
                  </div>
                </div>
              ))}
            </div>

            {/*
              第三行：脚本结构。这一块原来整个没展示，而它恰恰是"情绪曲线"
              这种通用 AI 根本给不出来的东西——它说的是观众从第几秒该有什么感觉。
            */}
            <h3 className="text-sm font-semibold tracking-widest text-muted-foreground mb-4">
              脚本结构 {FACTS.structures} 种 · 摘三种
            </h3>
            <div className="grid md:grid-cols-3 gap-5">
              {SHOWCASE_STRUCTURES.map((s) => (
                <div
                  key={s.id}
                  className="glass-panel rounded-2xl p-6 border-2 border-border hover:border-emerald-500/40 transition-colors"
                >
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-lg font-bold">{s.name}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{s.coreLogic}</p>
                  <div className="rounded-xl bg-emerald-500/[0.07] border border-emerald-500/20 px-3 py-2.5 mb-3">
                    <div className="text-[11px] font-medium tracking-wider text-emerald-500 mb-1">结构公式</div>
                    <div className="text-[13px] font-medium text-foreground">{s.formula}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    情绪曲线：{s.emotionCurve}
                  </div>
                </div>
              ))}
            </div>

            {/*
              八大爆款元素用紧凑的两列排，不做成大卡片——
              它的说服力在于"八个方向一次看全"，摊成八张大卡反而散了。
              每条都带真实句式，因为句式才是能直接套用的东西，
              「要有冲突感」那种说法是正确的废话。
            */}
            <h3 className="text-sm font-semibold tracking-widest text-muted-foreground mt-12 mb-4">
              八大爆款元素 · 给个行业就能套出八个方向
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {VIRAL_ELEMENTS.map((e) => (
                <div
                  key={e.name}
                  className="glass-panel rounded-xl px-4 py-3.5 border border-border hover:border-primary/40 transition-colors"
                >
                  <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1 mb-1.5">
                    <span className="font-bold">{e.name}</span>
                    <span className="text-xs text-muted-foreground">{e.hook}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {e.patterns.map((p) => (
                      <span
                        key={p}
                        className="text-[11px] px-2 py-1 rounded-md bg-primary/[0.08] border border-primary/20 text-foreground"
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <p className="text-center text-sm text-muted-foreground mt-10">
              以上是 {FACTS.methods} 条里的 {3 + 3 + 3 + FACTS.elements} 条。
              生成时 AI 会按你的资源条件挑出能拍的那几条，并守住每一条写明的边界。
            </p>
          </div>
        </div>
      </section>

      {/* 核心功能。下面列了 8 个最常用的；板块总数统一从 FACTS 取 */}
      <section id="features" className="py-20 px-4 glass-panel">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/15 dark:bg-blue-900/30 rounded-full mb-4">
              <Star className="w-4 h-4 text-primary" />
              {/* 素材库、创作进度是整理内容的地方，不算创作板块（FACTS.boards 不数它们），所以分开说 */}
              <span className="text-sm font-medium text-primary">{FACTS.boards} 个创作板块 + 素材库、创作进度</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="brand-gradient bg-clip-text text-transparent">
                策划与创作支持
              </span>
            </h2>
            <p className="text-xl text-muted-foreground">
              从想方向、拆爆款、定位到拍摄发布，每一步的结果都能带去下一步
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="group relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative glass-panel rounded-2xl p-6 border-2 border-border hover:border-primary/50 transition-all hover:shadow-xl h-full">
                    <div className={`w-14 h-14 ${colorClasses[feature.color]} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-7 h-7" />
                    </div>
                    <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-foreground">
                      {feature.title}
                      {"isNew" in feature && feature.isNew && (
                        <span className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[11px] font-semibold text-rose-500">新</span>
                      )}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                      {feature.desc}
                    </p>
                    <ul className="space-y-2">
                      {feature.benefits.map((benefit, bidx) => (
                        <li key={bidx} className="flex items-start gap-2 text-xs text-muted-foreground">
                          <Check className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <Link 
              href={REGISTER_URL} 
              className="inline-flex items-center gap-2 px-8 py-4 brand-gradient text-white rounded-xl font-semibold hover:scale-105 transition-transform shadow-lg"
            >
              立即体验全部功能
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* 价格对比 */}
      <section id="pricing" className="py-20 px-4 bg-muted dark:bg-muted">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/15 dark:bg-purple-900/30 rounded-full mb-4">
              <Crown className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">价格方案</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="brand-gradient bg-clip-text text-transparent">
                选择适合您的方案
              </span>
            </h2>
            <p className="text-xl text-muted-foreground">
              从免费体验到高频创作，总有一款适合您
            </p>
          </div>

          {/* 传统方式 vs 开物对比 */}
          <div className="max-w-5xl mx-auto mb-16 overflow-x-auto">
            <div className="glass-panel min-w-[32rem] rounded-2xl border-2 border-border overflow-hidden shadow-xl text-sm sm:text-base">
              <div className="grid grid-cols-4 gap-px bg-muted dark:bg-muted">
                <div className="bg-muted dark:bg-muted p-3 sm:p-4 font-bold text-center">对比项</div>
                <div className="bg-muted dark:bg-muted p-3 sm:p-4 font-bold text-center">传统方式</div>
                <div className="bg-primary/10 p-3 sm:p-4 text-center text-primary"><BrandWordmark /></div>
                <div className="bg-emerald-500/10 p-3 sm:p-4 font-bold text-center text-green-500">创作支持</div>
              </div>
              <div className="grid grid-cols-4 gap-px bg-muted dark:bg-muted">
                <div className="glass-panel p-3 sm:p-4">脚本产出</div>
                <div className="glass-panel p-3 sm:p-4 text-center text-muted-foreground">手动整理与撰写</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-semibold text-primary">AI 生成完整脚本</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-bold text-green-500">可继续细化</div>
              </div>
              <div className="grid grid-cols-4 gap-px bg-muted dark:bg-muted">
                <div className="glass-panel p-3 sm:p-4">编导方法</div>
                <div className="glass-panel p-3 sm:p-4 text-center text-muted-foreground">自行收集整理</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-semibold text-primary">{FACTS.methods} 条公式与句式</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-bold text-green-500">结构可选</div>
              </div>
              <div className="grid grid-cols-4 gap-px bg-muted dark:bg-muted">
                <div className="glass-panel p-3 sm:p-4">月度订阅</div>
                <div className="glass-panel p-3 sm:p-4 text-center text-muted-foreground">费用依工具而定</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-semibold text-primary">
                  ¥{SUBSCRIPTION_PLANS.basic.price}-{SUBSCRIPTION_PLANS.enterprise.price}
                </div>
                <div className="glass-panel p-3 sm:p-4 text-center font-bold text-green-500">按需选择</div>
              </div>
              <div className="grid grid-cols-4 gap-px bg-muted dark:bg-muted">
                <div className="glass-panel p-3 sm:p-4">参考拆解</div>
                <div className="glass-panel p-3 sm:p-4 text-center text-muted-foreground">手动整理画面口播</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-semibold text-primary">画面与口播分析</div>
                <div className="glass-panel p-3 sm:p-4 text-center font-bold text-green-500">可接跨行业二创</div>
              </div>
            </div>
          </div>

          {/* 4个定价方案 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {pricingPlans.map((plan, idx) => (
              <div key={idx} className={`relative ${plan.highlight ? 'md:scale-105' : ''}`}>
                {/*
                  下面那个徽章必须有 z-10。

                  徽章高 29px、只往上露出 16px（-top-4），剩下 13px 压在卡片上。
                  而卡片是 glass-panel，带 backdrop-filter——那会创建新的层叠
                  上下文，在两者 z-index 都是 auto 时，DOM 里靠后的卡片就画在
                  徽章上面，把它盖掉将近一半。
                  表现是「最受欢迎」被横着切了一刀，而不是不显示，所以很容易
                  被当成字体或行高的问题。

                  注意徽章和卡片是**兄弟**。页面上别处的徽章都是卡片的子元素，
                  子元素本来就画在父级背景之上，所以只有这一处会出事。
                */}
                {plan.highlight && (
                  <div className="absolute -top-4 left-1/2 z-10 -translate-x-1/2 px-4 py-1 brand-gradient text-white text-sm font-semibold rounded-full shadow-lg">
                    推荐方案
                  </div>
                )}
                <div className={`glass-panel rounded-2xl p-6 border-2 ${plan.highlight ? 'border-accent/50 shadow-2xl' : 'border-border'} hover:shadow-xl transition-all h-full flex flex-col`}>
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold mb-2 text-foreground">{plan.name}</h3>
                    <div className="mb-2">
                      <span className="text-4xl font-extrabold text-primary">¥{plan.price}</span>
                      <span className="text-muted-foreground">/{plan.period}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{plan.desc}</p>
                  </div>
                  
                  <ul className="space-y-3 mb-6 flex-1">
                    {plan.features.map((feature, fidx) => (
                      <li key={fidx} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link
                    href="/dashboard"
                    className={`w-full py-3 rounded-xl font-semibold text-center transition-all ${
                      plan.highlight
                        ? 'brand-gradient text-white hover:scale-105 shadow-lg'
                        : 'bg-muted dark:bg-muted text-foreground hover:bg-muted dark:hover:bg-muted'
                    }`}
                  >
                    {plan.cta}
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12 text-sm text-muted-foreground">
            {/*
              原来是「随时取消续费 · 数据完全保密」。没有自动续费，谈不上"取消"；
              生成时输入会发给 Dify 和 Claude 处理（隐私政策里写明了），
              说"完全保密"和隐私政策自相矛盾。
            */}
            <p>虚拟商品开通后不支持无理由退款 · 不会自动扣费 · 不出售你的数据</p>
            <p className="mt-3">
              <Link href="/pricing" className="text-primary hover:underline">查看逐项功能对比 →</Link>
              <span className="mx-2">·</span>
              <Link href="/terms" className="text-primary hover:underline">服务条款</Link>
            </p>
          </div>
        </div>
      </section>

      {/* FAQ常见问题 */}
      <section id="faq" className="py-20 px-4 glass-panel">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/15 dark:bg-green-900/30 rounded-full mb-4">
              <MessageCircle className="w-4 h-4 text-green-500" />
              <span className="text-sm font-medium text-green-500">常见问题</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                您可能关心的问题
              </span>
            </h2>
            <p className="text-xl text-muted-foreground">
              解答您的疑惑，让您放心使用
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="bg-muted rounded-xl border border-border overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-foreground/[0.06] dark:hover:bg-slate-750 transition-colors"
                >
                  <span className="font-semibold text-foreground pr-4">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform ${openFaq === idx ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === idx && (
                  <div className="px-6 pb-4 text-muted-foreground leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-4">
              还有其他问题？
            </p>
            {/*
              原来是一个"联系客服咨询"按钮，链接 weixin://——桌面端点了没反应，
              手机上也只是打开微信、并不会加上客服。直接把微信号亮出来，可选中复制。
            */}
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary/15 dark:bg-blue-900/30 text-primary rounded-lg font-medium">
              <MessageCircle className="w-5 h-5" />
              客服微信：<span className="select-all">13240286600</span>（手机同号）
            </div>
          </div>
        </div>
      </section>

      {/* 最终CTA */}
      <section className="py-20 px-4 brand-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-80 h-80 bg-white rounded-full blur-3xl" />
        </div>
        
        <div className="container mx-auto text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            准备好开始创作了吗？
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            {/* 原来写「加入1280+创作者」，那个数字是编的 */}
            从账号定位开始，一条内容从选题到分镜一路做完
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              href={REGISTER_URL} 
              className="group px-10 py-5 bg-white text-primary rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-2xl flex items-center gap-2"
            >
              立即免费开始
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <a 
              href="#features" 
              className="px-10 py-5 border-2 border-white text-white rounded-xl font-bold text-lg hover:bg-white/10 transition-colors"
            >
              了解更多
            </a>
          </div>
          <p className="mt-8 text-sm opacity-75">
            无需信用卡 · 免费开始使用 · 随时升级
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted text-muted-foreground py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2.5 mb-4">
                <BrandSeal size={30} />
                <span className="text-[19px] text-foreground">
                  <BrandWordmark latin />
                </span>
              </div>
              <p className="text-sm leading-relaxed">
                AI 智能生成的短视频创作助手，让创作更简单、更高效。
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4">产品</h4>
              <ul className="space-y-0.5 text-sm">
                <li><a href="#features" className="inline-block py-1.5 hover:text-white transition-colors">核心功能</a></li>
                <li><a href="#pricing" className="inline-block py-1.5 hover:text-white transition-colors">价格方案</a></li>
                {/* /pricing 有一张逐项的功能对比表，原来全站没有任何入口能走到 */}
                <li><Link href="/pricing" className="inline-block py-1.5 hover:text-white transition-colors">完整功能对比</Link></li>
                <li><Link href={REGISTER_URL} className="inline-block py-1.5 hover:text-white transition-colors">立即使用</Link></li>
              </ul>
            </div>

            {/*
              这一栏原来有「联系客服」（weixin://，桌面端点了没反应，手机上也只是
              打开微信、并不会加上客服）和「使用文档」（href="#"，没有文档）。
              客服改成直接写出微信号，没有文档就不放链接。
            */}
            <div>
              <h4 className="font-semibold text-white mb-4">支持</h4>
              <ul className="space-y-0.5 text-sm">
                <li><a href="#faq" className="inline-block py-1.5 hover:text-white transition-colors">常见问题</a></li>
                <li>客服微信：<span className="select-all text-white">13240286600</span></li>
              </ul>
            </div>

            {/* 原来三个都是 href="#"。「关于我们」没有内容可放，撤掉 */}
            <div>
              <h4 className="font-semibold text-white mb-4">关于</h4>
              <ul className="space-y-0.5 text-sm">
                <li><Link href="/privacy" className="inline-block py-1.5 hover:text-white transition-colors">隐私政策</Link></li>
                <li><Link href="/terms" className="inline-block py-1.5 hover:text-white transition-colors">服务条款</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-sm">
            <p>&copy; {new Date().getFullYear()} {BRAND_NAME}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
