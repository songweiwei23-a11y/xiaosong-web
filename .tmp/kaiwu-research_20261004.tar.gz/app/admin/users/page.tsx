"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Edit2, ChevronLeft, ChevronRight, Loader2, RefreshCw, AlertCircle, Crown, Ban, Unlock, RotateCcw, Eye, KeyRound, Copy } from "lucide-react";
import { notify, confirmDialog } from '@/components/ui/feedback';
import { SUBSCRIPTION_PLANS, getPlan } from '@/lib/config/plans';

/** 改套餐下拉里的说明：名字 + 价格 + 各板块次数范围，全部从配置读 */
function planOptionLabel(id: string): string {
  const p = getPlan(id);
  const price = p.price ? ` ${p.price}元/月` : '';
  if (p.totalQuota === -1) return `${p.name}${price}（无限使用）`;
  if (p.totalQuota !== null) return `${p.name}${price}（所有功能合计 ${p.totalQuota} 次/月）`;
  const n = Object.values(p.quotas).filter((v) => v >= 0);
  const lo = Math.min(...n);
  const hi = Math.max(...n);
  return `${p.name}${price}（各板块 ${lo === hi ? lo : `${lo}-${hi}`} 次）`;
}

type User = {
  user_id: string;
  email: string;
  full_name: string;
  membership_level: string;
  subscription_status: string;
  subscription_end: string | null;
  quota_details: {
    script: { used: number };
    topic: { used: number };
    positioning: { used: number };
    freeChat: { used: number };
    storyboard: { used: number };
    review: { used: number };
    title: { used: number };
    dealReason: { used: number };
  };
  total_used: number;
  period_end: string | null;
  created_at: string;
  last_sign_in_at: string;
  has_profile: boolean;
  has_subscription: boolean;
  has_quota: boolean;
};

export default function UsersPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [editPlan, setEditPlan] = useState("");
  const [editEndDate, setEditEndDate] = useState("");
  // 刚重置出来的临时密码。只在这个弹窗里出现一次，关掉就没了
  const [tempPw, setTempPw] = useState<{ email: string; password: string } | null>(null);

  useEffect(() => {
    fetchUsers();
  }, [page]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        pageSize: pageSize.toString(),
        search: search,
      });

      const response = await fetch(`/api/admin/users?${params}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || '获取用户列表失败');
      }

      const data = await response.json();
      setUsers(data.users || []);
      setTotal(data.total || 0);
    } catch (error: any) {
      console.error('获取用户失败:', error);
      notify(error.message || '获取用户列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchUsers();
    setRefreshing(false);
  };

  const handleUpdateMembership = async (userId: string, plan: string, endDate?: string) => {
    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          action: 'update_membership',
          plan,
          endDate: endDate || null
        }),
      });

      if (response.ok) {
        notify('会员等级更新成功！');
        setShowEditModal(false);
        fetchUsers();
      } else {
        const errorData = await response.json();
        notify(errorData.error || '更新失败');
      }
    } catch (error) {
      console.error('更新会员失败:', error);
      notify('更新失败');
    }
  };

  const handleResetQuota = async (userId: string) => {
    const confirmed = await confirmDialog('确定要重置该用户的配额吗？所有使用次数将清零。', {
      tone: 'danger',
      confirmText: '确定重置',
      title: '重置配额'
    });

    if (!confirmed) return;

    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          action: 'reset_quota'
        }),
      });

      if (response.ok) {
        notify('配额重置成功！');
        fetchUsers();
      } else {
        const errorData = await response.json();
        notify(errorData.error || '重置失败');
      }
    } catch (error) {
      console.error('重置配额失败:', error);
      notify('重置失败');
    }
  };

  /*
   * 替用户重置密码。
   *
   * 系统没有发信服务，用户忘了密码只能找客服。在这之前后台也没有
   * 重置入口——注册又是邀请制，忘了密码的人就永远进不来了。
   *
   * 临时密码只出现在这一次的弹窗里，关掉就再也看不到（它不进操作日志）。
   * 发出去之前，先在微信里核对对方的注册邮箱和付款记录。
   */
  const handleResetPassword = async (user: User) => {
    const confirmed = await confirmDialog(
      `给 ${user.email} 重置密码？他当前的密码会立刻失效。发临时密码前，请先在微信里核对对方身份。`,
      { tone: 'danger', confirmText: '确定重置', title: '重置密码' }
    );
    if (!confirmed) return;

    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.user_id, action: 'reset_password' }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.tempPassword) {
        notify(data.error || '重置失败');
        return;
      }
      setTempPw({ email: user.email, password: data.tempPassword });
    } catch (error) {
      console.error('重置密码失败:', error);
      notify('重置失败');
    }
  };

  const handleBanUser = async (userId: string) => {
    const confirmed = await confirmDialog('确定要封禁该用户吗？用户将无法使用任何功能。', {
      tone: 'danger',
      confirmText: '确定封禁',
      title: '封禁用户'
    });

    if (!confirmed) return;

    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          action: 'ban_user'
        }),
      });

      if (response.ok) {
        notify('用户已封禁');
        fetchUsers();
      } else {
        const errorData = await response.json();
        notify(errorData.error || '封禁失败');
      }
    } catch (error) {
      console.error('封禁用户失败:', error);
      notify('封禁失败');
    }
  };

  const handleUnbanUser = async (userId: string) => {
    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          action: 'unban_user'
        }),
      });

      if (response.ok) {
        notify('用户已解封');
        fetchUsers();
      } else {
        const errorData = await response.json();
        notify(errorData.error || '解封失败');
      }
    } catch (error) {
      console.error('解封用户失败:', error);
      notify('解封失败');
    }
  };

  const openEditModal = (user: User) => {
    setSelectedUser(user);
    setEditPlan(user.membership_level);
    setEditEndDate(user.subscription_end ? new Date(user.subscription_end).toISOString().split('T')[0] : '');
    setShowEditModal(true);
  };

  const openDetailModal = (user: User) => {
    setSelectedUser(user);
    setShowDetailModal(true);
  };

  const getLevelBadge = (level: string) => {
    const configs: any = {
      free: { label: '免费版', color: 'bg-muted text-foreground dark:bg-muted dark:text-foreground' },
      basic: { label: '基础版', color: 'bg-primary/15 text-primary dark:bg-blue-900 dark:text-primary' },
      pro: { label: '专业版', color: 'bg-accent/15 text-accent dark:bg-purple-900 dark:text-accent' },
      enterprise: { label: SUBSCRIPTION_PLANS.enterprise.name, color: 'bg-amber-500/15 text-yellow-500 dark:bg-yellow-900 dark:text-yellow-300' },
    };
    const config = configs[level] || configs.free;
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const getStatusBadge = (status: string) => {
    const configs: any = {
      active: { label: '正常', color: 'bg-emerald-500/15 text-green-500 dark:bg-green-900 dark:text-green-300' },
      inactive: { label: '已封禁', color: 'bg-destructive/15 text-destructive dark:bg-red-900 dark:text-destructive' },
    };
    // 认不出的状态别默认成「已封禁」——新用户就是这么被误显示成封禁的
    const config = configs[status] || { label: status || '未知', color: 'bg-muted text-muted-foreground' };
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const totalPages = Math.ceil(total / pageSize);

  return (
    <div className="p-8 bg-muted dark:bg-muted min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-3 sm:mb-8 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground sm:text-3xl">用户管理</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              管理所有注册用户、会员等级和配额（共 {total} 个用户）
            </p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:opacity-90 disabled:opacity-50 transition-colors"
          >
            <RefreshCw className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? '刷新中...' : '刷新数据'}
          </button>
        </div>

        {/* Table */}
        <div className="glass-panel rounded-xl shadow-lg overflow-hidden border border-border">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-[48rem] w-full divide-y divide-slate-200 dark:divide-slate-800">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">用户信息</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">会员等级</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">状态</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">配额使用</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">周期结束</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">操作</th>
                  </tr>
                </thead>
                <tbody className="glass-panel divide-y divide-slate-200 dark:divide-slate-800">
                  {users.map((user) => (
                    <tr key={user.user_id} className="hover:bg-foreground/[0.06] dark:hover:bg-muted transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-foreground">{user.full_name}</div>
                          <div className="text-sm text-muted-foreground">{user.email}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getLevelBadge(user.membership_level)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(user.subscription_status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-foreground">
                          {user.total_used} 次
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-muted-foreground">
                          {user.period_end ? new Date(user.period_end).toLocaleDateString('zh-CN') : '无限期'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openDetailModal(user)}
                            className="text-primary hover:text-primary dark:text-primary dark:hover:text-primary"
                            title="查看详情"
                          >
                            <Eye className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => openEditModal(user)}
                            className="text-accent hover:text-accent dark:text-accent dark:hover:text-accent"
                            title="修改会员"
                          >
                            <Crown className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleResetQuota(user.user_id)}
                            className="text-green-500 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300"
                            title="重置配额"
                          >
                            <RotateCcw className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleResetPassword(user)}
                            className="text-amber-500 hover:text-amber-400"
                            title="重置密码（用户忘记密码时用）"
                          >
                            <KeyRound className="h-5 w-5" />
                          </button>
                          {user.subscription_status === 'active' ? (
                            <button
                              onClick={() => handleBanUser(user.user_id)}
                              className="text-destructive hover:text-destructive dark:text-red-400 dark:hover:text-destructive"
                              title="封禁用户"
                            >
                              <Ban className="h-5 w-5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleUnbanUser(user.user_id)}
                              className="text-green-500 hover:text-green-500 dark:text-green-400 dark:hover:text-green-300"
                              title="解封用户"
                            >
                              <Unlock className="h-5 w-5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="glass-panel px-4 py-3 flex items-center justify-between border-t border-border">
              <div className="flex-1 flex justify-between sm:hidden">
                <button
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                  className="relative inline-flex items-center px-4 py-2 border border-border dark:border-border text-sm font-medium rounded-md text-foreground/80 glass-panel hover:bg-foreground/[0.06] dark:hover:bg-muted disabled:opacity-50"
                >
                  上一页
                </button>
                <button
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                  className="ml-3 relative inline-flex items-center px-4 py-2 border border-border dark:border-border text-sm font-medium rounded-md text-foreground/80 glass-panel hover:bg-foreground/[0.06] dark:hover:bg-muted disabled:opacity-50"
                >
                  下一页
                </button>
              </div>
              <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm text-foreground/80">
                    显示 <span className="font-medium">{(page - 1) * pageSize + 1}</span> 到{' '}
                    <span className="font-medium">{Math.min(page * pageSize, total)}</span> 共{' '}
                    <span className="font-medium">{total}</span> 个用户
                  </p>
                </div>
                <div>
                  <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                    <button
                      onClick={() => setPage(Math.max(1, page - 1))}
                      disabled={page === 1}
                      className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-border dark:border-border glass-panel text-sm font-medium text-muted-foreground hover:bg-foreground/[0.06] dark:hover:bg-muted disabled:opacity-50"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>
                    <span className="relative inline-flex items-center px-4 py-2 border border-border dark:border-border glass-panel text-sm font-medium text-foreground/80">
                      {page} / {totalPages}
                    </span>
                    <button
                      onClick={() => setPage(Math.min(totalPages, page + 1))}
                      disabled={page === totalPages}
                      className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-border dark:border-border glass-panel text-sm font-medium text-muted-foreground hover:bg-foreground/[0.06] dark:hover:bg-muted disabled:opacity-50"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                  </nav>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Edit Modal */}
        {tempPw && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="glass-panel max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-2xl border border-border p-5 shadow-2xl sm:p-6">
              <h3 className="mb-1 flex items-center gap-2 text-lg font-semibold text-foreground">
                <KeyRound className="h-5 w-5 text-amber-500" />
                密码已重置
              </h3>
              <p className="mb-4 text-sm text-muted-foreground">{tempPw.email}</p>

              <div className="mb-4 flex items-center gap-2 rounded-xl border border-border bg-muted/50 px-4 py-3">
                <code className="flex-1 select-all font-mono text-lg tracking-wider text-foreground">
                  {tempPw.password}
                </code>
                <button
                  onClick={() => {
                    // 复制的是整段话术，直接粘到微信里就能发
                    navigator.clipboard
                      .writeText(
                        `你的临时密码是：${tempPw.password}\n登录后请点右上角的邮箱进入「我的账户」，改成你自己的密码。`
                      )
                      .then(() => notify('已复制，可以直接粘贴到微信'))
                      .catch(() => notify('复制失败，请手动选中复制'));
                  }}
                  className="flex items-center gap-1 rounded-lg px-2 py-1 text-sm text-primary hover:bg-primary/10"
                >
                  <Copy className="h-4 w-4" />
                  复制话术
                </button>
              </div>

              <p className="mb-4 text-xs leading-relaxed text-amber-500">
                这个密码只显示这一次，关掉就看不到了（它不会写进操作日志）。
                发给用户，并提醒他登录后到「我的账户」里改掉。
              </p>

              <button
                onClick={() => setTempPw(null)}
                className="w-full rounded-lg bg-primary py-2.5 font-medium text-white hover:opacity-90"
              >
                已发给用户，关闭
              </button>
            </div>
          </div>
        )}

        {showEditModal && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="glass-panel max-h-[90dvh] overflow-y-auto rounded-xl p-5 sm:p-6 max-w-md w-full mx-4 shadow-2xl">
              <h3 className="text-xl font-bold text-foreground mb-4">修改会员等级</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground/80 mb-2">
                    用户: {selectedUser.email}
                  </label>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground/80 mb-2">
                    会员套餐
                  </label>
                  <select
                    value={editPlan}
                    onChange={(e) => setEditPlan(e.target.value)}
                    className="w-full px-3 py-2 border border-border dark:border-border rounded-lg glass-panel text-foreground focus:ring-2 focus:ring-primary"
                  >
                    {/* 从套餐配置现算：这里原来写死，四项全过时了（写着 30 元 150 次、500 次） */}
                    {Object.keys(SUBSCRIPTION_PLANS).map((id) => (
                      <option key={id} value={id}>{planOptionLabel(id)}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground/80 mb-2">
                    到期时间（可选）
                  </label>
                  <input
                    type="date"
                    value={editEndDate}
                    onChange={(e) => setEditEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-border dark:border-border rounded-lg glass-panel text-foreground focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => handleUpdateMembership(selectedUser.user_id, editPlan, editEndDate)}
                    className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:opacity-90 transition-colors"
                  >
                    确定修改
                  </button>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 px-4 py-2 bg-muted dark:bg-muted text-foreground rounded-lg hover:bg-muted dark:hover:bg-muted transition-colors"
                  >
                    取消
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Detail Modal */}
        {showDetailModal && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="glass-panel max-h-[90dvh] overflow-y-auto rounded-xl p-5 sm:p-6 max-w-2xl w-full mx-4 shadow-2xl">
              <h3 className="text-xl font-bold text-foreground mb-4">用户详细信息</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">邮箱</p>
                    <p className="text-sm font-medium text-foreground">{selectedUser.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">姓名</p>
                    <p className="text-sm font-medium text-foreground">{selectedUser.full_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">会员等级</p>
                    <p className="text-sm font-medium text-foreground">{getLevelBadge(selectedUser.membership_level)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">账号状态</p>
                    <p className="text-sm font-medium text-foreground">{getStatusBadge(selectedUser.subscription_status)}</p>
                  </div>
                </div>

                <div className="border-t border-border pt-4">
                  <p className="text-sm font-medium text-foreground mb-3">功能使用情况</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">脚本生成</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.script.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">选题策划</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.topic.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">账号定位</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.positioning.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">自由对话</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.freeChat.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">分镜脚本</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.storyboard.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">审稿优化</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.review.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">标题封面</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.title.used}</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">成交理由</p>
                      <p className="text-lg font-bold text-foreground">{selectedUser.quota_details.dealReason.used}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="flex-1 px-4 py-2 bg-muted dark:bg-muted text-foreground rounded-lg hover:bg-muted dark:hover:bg-muted transition-colors"
                  >
                    关闭
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
