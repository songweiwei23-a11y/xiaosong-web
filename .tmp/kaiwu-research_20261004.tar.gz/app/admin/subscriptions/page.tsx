"use client";

import { useState, useEffect } from "react";
import { Crown, Edit, Save, X, Calendar, Zap, RefreshCw, Search } from "lucide-react";
import { notify, confirmDialog } from '@/components/ui/feedback';
import { Loading } from '@/components/ui/loading';
import { SUBSCRIPTION_PLANS, quotaSummary } from '@/lib/config/plans';

/**
 * 套餐徽章的配色。必须是完整的类名字面量——
 * Tailwind 在构建时扫描源码收集用到的类，`bg-${color}-100` 这种运行时
 * 拼出来的字符串它看不见，对应的样式压根不会生成。
 * 页面上那些徽章此前一直是没有底色的。
 */
const PLAN_BADGE: Record<string, string> = {
  free: 'bg-muted text-muted-foreground',
  basic: 'bg-blue-500/15 text-blue-600 dark:text-blue-400',
  pro: 'bg-purple-500/15 text-purple-600 dark:text-purple-400',
  enterprise: 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
};

interface UserSubscription {
  id: string;
  user_id: string;
  email: string;
  plan: string;
  status: string;
  quota: { used: number; total: number };
  startDate: string;
  endDate: string | null;
}

export default function SubscriptionsManagement() {
  const [users, setUsers] = useState<UserSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [planFilter, setPlanFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [editForm, setEditForm] = useState({
    plan: "",
    endDate: "",
  });

  useEffect(() => {
    loadSubscriptions();
  }, [planFilter]);

  const loadSubscriptions = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (planFilter !== 'all') {
        params.append('plan', planFilter);
      }
      
      const response = await fetch(`/api/admin/subscriptions?${params}`);
      const data = await response.json();
      
      if (response.ok) {
        setUsers(data.subscriptions || []);
      } else {
        notify(data.error || '加载失败', 'error');
      }
    } catch (error) {
      console.error('加载会员列表失败:', error);
      notify('加载失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  /*
   * 套餐名称与额度说明一律从 lib/config/plans 取。
   *
   * 这里原先写死着 free 50 / basic 150 / pro 500——改价改额度之后三个数字
   * 全错，而后台正是管理员判断「这人该有多少额度」的地方，
   * 显示错的数字比不显示更糟。颜色是纯展示，留在页面里。
   */
  const planInfo: Record<string, { label: string; quotaText: string }> =
    Object.fromEntries(
      (Object.keys(SUBSCRIPTION_PLANS) as (keyof typeof SUBSCRIPTION_PLANS)[]).map((id) => [
        id,
        { label: SUBSCRIPTION_PLANS[id].name, quotaText: quotaSummary(id)[0] },
      ])
    );

  const handleEdit = (user: UserSubscription) => {
    setEditingId(user.user_id);
    setEditForm({
      plan: user.plan,
      endDate: user.endDate || "",
    });
  };

  const handleSave = async (userId: string) => {
    try {
      const response = await fetch('/api/admin/subscriptions', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          plan: editForm.plan,
          endDate: editForm.endDate,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        notify(data.message || '会员信息已更新', 'success');
        setEditingId(null);
        loadSubscriptions();
      } else {
        notify(data.error || '更新失败', 'error');
      }
    } catch (error) {
      console.error('更新失败:', error);
      notify('更新失败', 'error');
    }
  };

  const handleCancel = () => {
    setEditingId(null);
  };

  const handleResetQuota = async (userId: string) => {
    if (await confirmDialog("确定要重置该用户的本月使用额度吗？")) {
      try {
        const response = await fetch('/api/admin/subscriptions', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            action: 'reset_quota',
          }),
        });

        const data = await response.json();

        if (response.ok) {
          notify(data.message || '额度已重置', 'success');
          loadSubscriptions();
        } else {
          notify(data.error || '重置失败', 'error');
        }
      } catch (error) {
        console.error('重置失败:', error);
        notify('重置失败', 'error');
      }
    }
  };

  const filteredUsers = users.filter(user =>
    searchTerm === '' ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // 统计
  const stats = {
    total: users.length,
    free: users.filter(u => u.plan === 'free').length,
    basic: users.filter(u => u.plan === 'basic').length,
    pro: users.filter(u => u.plan === 'pro').length,
    enterprise: users.filter(u => u.plan === 'enterprise').length,
  };

  if (loading) {
    return <Loading size="lg" text="加载会员数据..." fullScreen />;
  }

  return (
    <div className="min-h-screen">
      <div className="border-b glass-panel shadow-sm">
        <div className="container mx-auto px-8 py-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold brand-gradient bg-clip-text text-transparent flex items-center gap-2">
                <Crown className="w-8 h-8 text-accent" />
                会员管理
              </h1>
              <p className="text-sm text-muted-foreground mt-1">管理用户会员权限和额度</p>
            </div>
            <button
              onClick={loadSubscriptions}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg hover:bg-accent"
            >
              <RefreshCw className="w-4 h-4" />
              刷新
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-8 py-10">
        {/* 统计卡片 */}
        <div className="grid grid-cols-2 gap-3 mb-6 sm:grid-cols-3 sm:gap-4 md:grid-cols-5">
          <div className="bg-card border rounded-lg p-4">
            <div className="text-sm text-muted-foreground">总会员</div>
            <div className="text-2xl font-bold">{stats.total}</div>
          </div>
          <div className="bg-muted border border-border rounded-lg p-4">
            <div className="text-sm text-muted-foreground">免费版</div>
            <div className="text-2xl font-bold text-foreground/80">{stats.free}</div>
          </div>
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
            <div className="text-sm text-primary">基础会员</div>
            <div className="text-2xl font-bold text-primary">{stats.basic}</div>
          </div>
          <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
            <div className="text-sm text-accent">专业会员</div>
            <div className="text-2xl font-bold text-accent">{stats.pro}</div>
          </div>
          <div className="bg-amber-500/10 border border-orange-500/25 rounded-lg p-4">
            <div className="text-sm text-orange-500">企业版</div>
            <div className="text-2xl font-bold text-orange-500">{stats.enterprise}</div>
          </div>
        </div>

        {/* 筛选和搜索 */}
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="搜索用户邮箱..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
            />
          </div>
          <select
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
            className="px-4 py-2 border rounded-lg"
          >
            <option value="all">全部套餐</option>
            <option value="free">免费版</option>
            <option value="basic">基础会员</option>
            <option value="pro">专业会员</option>
            <option value="enterprise">企业版</option>
          </select>
        </div>

        {/* 用户列表 */}
        <div className="bg-card border rounded-lg overflow-x-auto">
          <table className="w-full min-w-[44rem]">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold">用户</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">套餐</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">额度使用</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">到期时间</th>
                <th className="px-4 py-3 text-right text-sm font-semibold">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                    暂无数据
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.user_id} className="border-t hover:bg-muted/50">
                    <td className="px-4 py-3">
                      <div className="text-sm font-medium">{user.email}</div>
                      <div className="text-xs text-muted-foreground">ID: {user.user_id.slice(0, 8)}...</div>
                    </td>
                    <td className="px-4 py-3">
                      {editingId === user.user_id ? (
                        <select
                          value={editForm.plan}
                          onChange={(e) => setEditForm({ ...editForm, plan: e.target.value })}
                          className="px-2 py-1 border rounded text-sm"
                        >
                          {(Object.keys(SUBSCRIPTION_PLANS) as (keyof typeof SUBSCRIPTION_PLANS)[]).map((id) => (
                            <option key={id} value={id}>{SUBSCRIPTION_PLANS[id].name}</option>
                          ))}
                        </select>
                      ) : (
                        <div>
                          {/* 类名必须是完整字面量。原先写的是 bg-${color}-100，
                              Tailwind 在构建时扫不到运行时拼出来的类名，
                              这些底色从来就没生成过，徽章一直是透明的 */}
                          <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${PLAN_BADGE[user.plan] ?? PLAN_BADGE.free}`}>
                            {planInfo[user.plan]?.label || user.plan}
                          </span>
                          <div className="mt-1 text-[11px] text-muted-foreground">
                            {planInfo[user.plan]?.quotaText}
                          </div>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="text-sm">
                          {user.quota.used} / {user.quota.total === -1 ? '无限' : user.quota.total}
                        </div>
                        {user.quota.total !== -1 && (
                          <div className="flex-1 bg-muted rounded-full h-2 max-w-[100px]">
                            <div
                              className="bg-accent h-2 rounded-full"
                              style={{
                                width: `${Math.min((user.quota.used / user.quota.total) * 100, 100)}%`,
                              }}
                            />
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {editingId === user.user_id ? (
                        <input
                          type="date"
                          value={editForm.endDate ? editForm.endDate.split('T')[0] : ''}
                          onChange={(e) => setEditForm({ ...editForm, endDate: e.target.value })}
                          className="px-2 py-1 border rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm">
                          {user.endDate ? new Date(user.endDate).toLocaleDateString() : '永久'}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {editingId === user.user_id ? (
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleSave(user.user_id)}
                            className="p-1 text-green-500 hover:bg-emerald-500/10 rounded"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={handleCancel}
                            className="p-1 text-muted-foreground hover:bg-foreground/[0.06] rounded"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleEdit(user)}
                            className="p-1 text-primary hover:bg-primary/10 rounded"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleResetQuota(user.user_id)}
                            className="p-1 text-accent hover:bg-accent/10 rounded"
                            title="重置额度"
                          >
                            <Zap className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}